#pragma once
#include "data/databaseconnection.hpp"
#include <string>
#include <vector>

struct User { int id; std::string name; };

class UserRepository {
    DatabaseConnection& conn;
public:
    explicit UserRepository(DatabaseConnection& c): conn(c) {}
    bool init();
    std::vector<User> all();
    bool add(const std::string& name);
};
