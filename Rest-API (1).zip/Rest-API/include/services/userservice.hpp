#pragma once
#include "data/userrepository.hpp"
#include "models/user.hpp"
#include <vector>
#include <string>
#include <optional>

class UserService {
private:
    UserRepository& repository;

public:
    explicit UserService(UserRepository& repository) : repository(repository) {}

    // Operații CRUD cu validări
    std::vector<User> getAllUsers();
    std::optional<User> getUserById(int id);
    User createUser(const std::string& name, const std::string& email);
    void updateUser(int id, const User& user);
    void deleteUser(int id);

    // Validări business logic
    void validateEmail(const std::string& email);
    void validateUser(const User& user);
    void validateUserForUpdate(int id);
};
