
#pragma once
#include <string>

namespace Worker {
    void handle_client(int client_fd);
    std::string read_request(int fd);
    void send_response(int fd, const std::string& response);
    void initialize();
}
