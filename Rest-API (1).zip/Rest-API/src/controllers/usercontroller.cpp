#include "controllers/usercontroller.hpp"
#include <iostream>
#include <sstream>

void UserController::setRawRequest(const std::string& raw) {
    raw_request = raw;
}

std::string UserController::extractBody(const std::string& raw_req) {
    // Găsește body-ul după \r\n\r\n
    size_t pos = raw_req.find("\r\n\r\n");
    if (pos == std::string::npos) {
        return "";
    }
    return raw_req.substr(pos + 4);
}

std::string UserController::jsonResponse(int status, const std::string& body) {
    std::ostringstream response;
    response << "HTTP/1.1 " << status;
    
    switch (status) {
        case 200: response << " OK"; break;
        case 201: response << " Created"; break;
        case 204: response << " No Content"; break;
        case 400: response << " Bad Request"; break;
        case 404: response << " Not Found"; break;
        case 500: response << " Internal Server Error"; break;
        default: response << " Unknown"; break;
    }
    
    response << "\r\n";
    response << "Content-Type: application/json\r\n";
    response << "Content-Length: " << body.length() << "\r\n";
    response << "Connection: close\r\n";
    response << "\r\n";
    response << body;
    
    return response.str();
}

std::string UserController::getAll(const HttpRequest& req, const std::map<std::string, std::string>& params) {
    std::cout << "[UserController] GET /api/users\n";
    
    try {
        auto users = service.getAllUsers();
        
        // Construiește JSON array
        std::ostringstream json;
        json << "[";
        for (size_t i = 0; i < users.size(); ++i) {
            json << users[i].toJson();
            if (i < users.size() - 1) {
                json << ",";
            }
        }
        json << "]";
        
        return jsonResponse(200, json.str());
    } catch (const std::exception& e) {
        std::ostringstream error;
        error << "{\"error\":\"" << e.what() << "\"}";
        return jsonResponse(500, error.str());
    }
}

std::string UserController::getById(const HttpRequest& req, const std::map<std::string, std::string>& params) {
    std::cout << "[UserController] GET /api/users/:id\n";
    
    try {
        // Extrage ID din parametri
        auto it = params.find("id");
        if (it == params.end()) {
            return jsonResponse(400, "{\"error\":\"ID lipsă\"}");
        }
        
        int id = std::stoi(it->second);
        auto user = service.getUserById(id);
        
        if (!user.has_value()) {
            std::ostringstream error;
            error << "{\"error\":\"User cu ID=" << id << " nu a fost găsit\"}";
            return jsonResponse(404, error.str());
        }
        
        return jsonResponse(200, user->toJson());
    } catch (const std::invalid_argument& e) {
        std::ostringstream error;
        error << "{\"error\":\"" << e.what() << "\"}";
        return jsonResponse(400, error.str());
    } catch (const std::exception& e) {
        std::ostringstream error;
        error << "{\"error\":\"" << e.what() << "\"}";
        return jsonResponse(500, error.str());
    }
}

std::string UserController::create(const HttpRequest& req, const std::map<std::string, std::string>& params) {
    std::cout << "[UserController] POST /api/users\n";
    
    try {
        // Extrage body-ul
        std::string body = extractBody(raw_request);
        std::cout << "[UserController] Body: " << body << "\n";
        
        if (body.empty()) {
            return jsonResponse(400, "{\"error\":\"Body lipsă\"}");
        }
        
        // Parsează JSON (simplu)
        User user = User::fromJson(body);
        
        // Creează user-ul
        User created = service.createUser(user.name, user.email);
        
        return jsonResponse(201, created.toJson());
    } catch (const std::invalid_argument& e) {
        std::ostringstream error;
        error << "{\"error\":\"" << e.what() << "\"}";
        return jsonResponse(400, error.str());
    } catch (const std::exception& e) {
        std::ostringstream error;
        error << "{\"error\":\"" << e.what() << "\"}";
        return jsonResponse(500, error.str());
    }
}

std::string UserController::update(const HttpRequest& req, const std::map<std::string, std::string>& params) {
    std::cout << "[UserController] PUT /api/users/:id\n";
    
    try {
        // Extrage ID
        auto it = params.find("id");
        if (it == params.end()) {
            return jsonResponse(400, "{\"error\":\"ID lipsă\"}");
        }
        int id = std::stoi(it->second);
        
        // Extrage body
        std::string body = extractBody(raw_request);
        if (body.empty()) {
            return jsonResponse(400, "{\"error\":\"Body lipsă\"}");
        }
        
        // Parsează JSON
        User user = User::fromJson(body);
        
        // Update
        service.updateUser(id, user);
        
        // Obține user-ul actualizat
        auto updated = service.getUserById(id);
        if (updated.has_value()) {
            return jsonResponse(200, updated->toJson());
        } else {
            return jsonResponse(200, "{\"message\":\"User actualizat cu succes\"}");
        }
    } catch (const std::invalid_argument& e) {
        std::ostringstream error;
        error << "{\"error\":\"" << e.what() << "\"}";
        return jsonResponse(400, error.str());
    } catch (const std::exception& e) {
        std::ostringstream error;
        error << "{\"error\":\"" << e.what() << "\"}";
        return jsonResponse(500, error.str());
    }
}

std::string UserController::remove(const HttpRequest& req, const std::map<std::string, std::string>& params) {
    std::cout << "[UserController] DELETE /api/users/:id\n";
    
    try {
        // Extrage ID
        auto it = params.find("id");
        if (it == params.end()) {
            return jsonResponse(400, "{\"error\":\"ID lipsă\"}");
        }
        int id = std::stoi(it->second);
        
        // Șterge
        service.deleteUser(id);
        
        return jsonResponse(200, "{\"message\":\"User șters cu succes\"}");
    } catch (const std::invalid_argument& e) {
        std::ostringstream error;
        error << "{\"error\":\"" << e.what() << "\"}";
        return jsonResponse(400, error.str());
    } catch (const std::exception& e) {
        std::ostringstream error;
        error << "{\"error\":\"" << e.what() << "\"}";
        return jsonResponse(500, error.str());
    }
}
