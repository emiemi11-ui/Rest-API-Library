#include "core/worker.hpp"
#include "http/request.hpp"
#include "http/response.hpp"
#include "http/router.hpp"
#include "data/databaseconnection.hpp"
#include "data/userrepository.hpp"
#include "services/userservice.hpp"
#include "controllers/usercontroller.hpp"
#include <unistd.h>
#include <sys/socket.h>
#include <vector>
#include <iostream>
#include <memory>

namespace Worker {

// Singleton-uri pentru componentele aplicației
static std::unique_ptr<DatabaseConnection> db_connection;
static std::unique_ptr<UserRepository> user_repository;
static std::unique_ptr<UserService> user_service;
static std::unique_ptr<UserController> user_controller;
static std::unique_ptr<Router> router;
static bool initialized = false;

void initialize() {
    if (initialized) return;
    
    std::cout << "[Worker] Inițializare componente...\n";
    
    // Creează conexiunea la baza de date
    db_connection = std::make_unique<DatabaseConnection>("localhost", "root", "", "myapp_db");
    db_connection->connect();
    
    // Creează straturile
    user_repository = std::make_unique<UserRepository>(*db_connection);
    user_service = std::make_unique<UserService>(*user_repository);
    user_controller = std::make_unique<UserController>(*user_service);
    
    // Creează router-ul și înregistrează rutele
    router = std::make_unique<Router>();
    
    // Înregistrare rute pentru API users
    router->get("/api/users", [](const HttpRequest& req, const std::map<std::string, std::string>& params) {
        return user_controller->getAll(req, params);
    });
    
    router->get("/api/users/:id", [](const HttpRequest& req, const std::map<std::string, std::string>& params) {
        return user_controller->getById(req, params);
    });
    
    router->post("/api/users", [](const HttpRequest& req, const std::map<std::string, std::string>& params) {
        return user_controller->create(req, params);
    });
    
    router->put("/api/users/:id", [](const HttpRequest& req, const std::map<std::string, std::string>& params) {
        return user_controller->update(req, params);
    });
    
    router->del("/api/users/:id", [](const HttpRequest& req, const std::map<std::string, std::string>& params) {
        return user_controller->remove(req, params);
    });
    
    // Health check endpoint
    router->get("/health", [](const HttpRequest& req, const std::map<std::string, std::string>& params) {
        return "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nConnection: close\r\n\r\n{\"status\":\"ok\"}";
    });
    
    // Root endpoint
    router->get("/", [](const HttpRequest& req, const std::map<std::string, std::string>& params) {
        return "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nConnection: close\r\n\r\nREST API Server - OK";
    });
    
    initialized = true;
    std::cout << "[Worker] Inițializare completă!\n";
}

std::string read_request(int fd){
    std::vector<char> buf(8192);
    ssize_t n = ::recv(fd, buf.data(), buf.size()-1, 0);
    if (n <= 0) return std::string();
    buf[n]=0;
    return std::string(buf.data());
}

void send_response(int fd, const std::string& response){
    ::send(fd, response.data(), response.size(), 0);
}

void handle_client(int client_fd){
    // Inițializează componentele (doar o dată)
    initialize();
    
    // Citește cererea
    std::string raw = read_request(client_fd);
    if (raw.empty()){ 
        ::close(client_fd); 
        return; 
    }
    
    std::cout << "\n[Worker] ========== CERERE NOUĂ ==========\n";
    
    // Parsează cererea
    HttpRequest req = parse_request_line(raw);
    std::cout << "[Worker] " << req.method << " " << req.path << "\n";
    
    // Setează raw request pentru controller (pentru a putea extrage body-ul)
    user_controller->setRawRequest(raw);
    
    // Procesează prin router
    std::string response = router->handle(req);
    
    // Trimite răspunsul
    send_response(client_fd, response);
    
    std::cout << "[Worker] Răspuns trimis\n";
    std::cout << "[Worker] =====================================\n\n";
    
    // Închide conexiunea
    ::shutdown(client_fd, SHUT_RDWR);
    ::close(client_fd);
}
}
