#include "data/userrepository.hpp"
#include <sstream>

bool UserRepository::init() {
    // tabel minimal pentru demo; extinde-l cum ai nevoie
    conn.db().execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL)");
    return true;
}

std::vector<User> UserRepository::all() {
    std::vector<User> v;
    for (auto& row : conn.db().query("SELECT id, name FROM users ORDER BY id ASC")) {
        User u{};
        if (row.count("id"))   u.id = std::stoi(row.at("id"));
        if (row.count("name")) u.name = row.at("name");
        v.push_back(std::move(u));
    }
    return v;
}

bool UserRepository::add(const std::string& name) {
    std::ostringstream ss;
    // NB: pentru producție folosește SQL parametrizat; aici e demo minim
    ss << "INSERT INTO users(name) VALUES('" << name << "')";
    return conn.db().execute(ss.str());
}
