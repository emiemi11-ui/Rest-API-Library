#include "services/userservice.hpp"
#include <iostream>
#include <stdexcept>
#include <regex>

std::vector<User> UserService::getAllUsers() {
    std::cout << "[UserService] getAllUsers()\n";
    return repository.findAll();
}

std::optional<User> UserService::getUserById(int id) {
    std::cout << "[UserService] getUserById(" << id << ")\n";
    
    if (id <= 0) {
        throw std::invalid_argument("ID invalid: trebuie să fie pozitiv");
    }
    
    return repository.findById(id);
}

User UserService::createUser(const std::string& name, const std::string& email) {
    std::cout << "[UserService] createUser(" << name << ", " << email << ")\n";
    
    // Validări
    if (name.empty()) {
        throw std::invalid_argument("Numele nu poate fi gol");
    }
    if (name.length() > 255) {
        throw std::invalid_argument("Numele este prea lung (max 255 caractere)");
    }
    
    validateEmail(email);
    
    // Verifică dacă email-ul există deja
    if (repository.existsByEmail(email)) {
        throw std::invalid_argument("Email-ul există deja: " + email);
    }
    
    // Creează user-ul
    User user;
    user.name = name;
    user.email = email;
    
    return repository.save(user);
}

void UserService::updateUser(int id, const User& user) {
    std::cout << "[UserService] updateUser(" << id << ")\n";
    
    validateUserForUpdate(id);
    validateUser(user);
    
    // Verifică dacă email-ul este folosit de alt user
    auto existing = repository.findByEmail(user.email);
    if (existing.has_value() && existing->id != id) {
        throw std::invalid_argument("Email-ul este folosit de alt utilizator");
    }
    
    User updated_user = user;
    updated_user.id = id;
    
    repository.update(updated_user);
}

void UserService::deleteUser(int id) {
    std::cout << "[UserService] deleteUser(" << id << ")\n";
    
    validateUserForUpdate(id);
    repository.deleteById(id);
}

void UserService::validateEmail(const std::string& email) {
    if (email.empty()) {
        throw std::invalid_argument("Email-ul nu poate fi gol");
    }
    
    if (email.length() > 255) {
        throw std::invalid_argument("Email-ul este prea lung (max 255 caractere)");
    }
    
    // Validare simplă de email
    std::regex email_regex(R"([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})");
    if (!std::regex_match(email, email_regex)) {
        throw std::invalid_argument("Format email invalid: " + email);
    }
}

void UserService::validateUser(const User& user) {
    if (user.name.empty()) {
        throw std::invalid_argument("Numele nu poate fi gol");
    }
    if (user.name.length() > 255) {
        throw std::invalid_argument("Numele este prea lung (max 255 caractere)");
    }
    validateEmail(user.email);
}

void UserService::validateUserForUpdate(int id) {
    if (id <= 0) {
        throw std::invalid_argument("ID invalid: trebuie să fie pozitiv");
    }
    
    auto user = repository.findById(id);
    if (!user.has_value()) {
        throw std::invalid_argument("Utilizatorul cu ID=" + std::to_string(id) + " nu există");
    }
}
