#include "core/server.hpp"
#include "http/router.hpp"
#include "http/request.hpp"
#include "http/response.hpp"

#include "data/sqlitedatabase.hpp"
#include "data/databaseconnection.hpp"
#include "data/userrepository.hpp"

#include <iostream>
#include <memory>
#include <cstdlib>
#include <map>
#include <string>

// --- helper minim pentru parsing de query din target (/path?key=val&...)
static std::map<std::string,std::string> parseQuery(const std::string& target) {
    std::map<std::string,std::string> out;
    auto qpos = target.find('?');
    if (qpos == std::string::npos) return out;
    auto q = target.substr(qpos + 1);
    size_t i = 0;
    while (i < q.size()) {
        size_t amp = q.find('&', i);
        std::string pair = (amp == std::string::npos) ? q.substr(i) : q.substr(i, amp - i);
        size_t eq = pair.find('=');
        std::string k = (eq == std::string::npos) ? pair : pair.substr(0, eq);
        std::string v = (eq == std::string::npos) ? ""   : pair.substr(eq + 1);
        out[k] = v; // NB: fără URL decode pentru simplitate
        if (amp == std::string::npos) break;
        i = amp + 1;
    }
    return out;
}

int main(int argc, char** argv) {
    int port = 8080;
    if (argc > 1) port = std::atoi(argv[1]);

    // 1) DB: SQLite prin interfața generică
    auto sqlite = std::make_unique<SqliteDatabase>();
    DatabaseConnection db(std::move(sqlite), {{"file","app.db"}});
    if (!db.connect()) {
        std::cerr << "Eroare: nu m-am putut conecta la SQLite (app.db)\n";
        return 1;
    }

    UserRepository users(db);
    users.init();

    // 2) Router: rute REST
    Router router;

    // GET /api/users -> listă JSON
    // !!! Handler cu 2 parametri: (req, params)
    router.get("/api/users", [&users](const HttpRequest& req,
                                      const std::map<std::string,std::string>& params) {
        (void)req;    // nefolosit aici
        (void)params; // nefolosit aici

        auto list = users.all();
        std::string body = "[";
        for (size_t i=0;i<list.size();++i) {
            body += "{\"id\":" + std::to_string(list[i].id) +
                    ",\"name\":\"" + list[i].name + "\"}";
            if (i+1<list.size()) body += ",";
        }
        body += "]";
        return HttpResponse::json(200, body);
    });

    // POST /api/users/add?name=Ana
    router.post("/api/users/add", [&users](const HttpRequest& req,
                                           const std::map<std::string,std::string>& params) {
        (void)params; // ruta nu are :param, doar query

        auto q = parseQuery(req.target);
        auto it = q.find("name");
        if (it == q.end() || it->second.empty()) {
            return HttpResponse::json(400, "{\"error\":\"missing name\"}");
        }
        bool ok = users.add(it->second);
        return HttpResponse::json(ok ? 201 : 500, ok ? "{\"ok\":true}" : "{\"ok\":false}");
    });

    // 3) Server HTTP
    Server server(port, 4);       // 4 workeri
    server.setRouter(router);     // asigură-te că ai metoda asta în Server
    std::cout << "Server ON: http://localhost:" << port << "\n";
    server.start();
    return 0;
}
